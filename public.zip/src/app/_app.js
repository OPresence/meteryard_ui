import ClientPage from "../pages/index";
function MyApp({ Component, pageProps }) {
  return (
    <>
      <ClientPage />
    </>
  );
}

export default MyApp;
