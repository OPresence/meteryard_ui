import React from "react";
import { Avatar, Box, Typography } from "@mui/material";
import "../Scss/scroll.css";
const ChatBoat = () => {
  const chatJson = [
    {
      type: "text",
      text: "Hello Steve",
      from: "jid_1109",
      sender_name: "Michel Slatter",
      to: "jid_1111",
    },
    {
      type: "text",
      text: "Hi Michael",
      from: "jid_1111",
      sender_name: "Steve Jobs",
      to: "jid_1109",
    },
    {
      type: "text",
      text: "Check this below destination",
      from: "jid_1109",
      sender_name: "Michel Slatter",
      to: "jid_1111",
    },
    {
      type: "text",
      text: "Hello Steve",
      from: "jid_1109",
      sender_name: "Michel Slatter",
      to: "jid_1111",
    },
    {
      type: "text",
      text: "Hi Michael",
      from: "jid_1111",
      sender_name: "Steve Jobs",
      to: "jid_1109",
    },
    {
      type: "text",
      text: "Check this below destination",
      from: "jid_1109",
      sender_name: "Michel Slatter",
      to: "jid_1111",
    },
    // {
    //   type: "text",
    //   text: "Can  you send few more",
    //   from: "jid_1111",
    //   sender_name: "Steve Jobs",
    //   to: "jid_1109",
    // },
    // {
    //   type: "text",
    //   text: "Here are few more travel destinations around europe, united states of america, japan, southern america, south africa, congo, sri lanka, west indies, green land and australia",
    //   from: "jid_1109",
    //   sender_name: "Michel Slatter",
    //   to: "jid_1111",
    // },
  ];

  return (
    <div>
      <Box
        style={{
          position: "absolute",
          background: "#fff",
          top: "115px",
          right: "22px",
          zIndex: 1,
          borderRadius: "20px",
          maxWidth: 500,
          overflow: "hidden",
          boxShadow:
            "rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px",
        }}
      >
        <Box width={300}>
          <Box
            style={{
              background:
                "transparent linear-gradient(270deg, #EA6F6F 0%, #565656 100%) 0% 0%",
              padding: "20px",
            }}
          >
            <Box>
              <Box
                height={50}
                width={50}
                display={"flex"}
                justifyContent={"center"}
                alignItems={"center"}
                style={{
                  background: "#fff",
                  borderRadius: "50px",
                }}
              >
                <img
                  src="/images/meteryard/Images/profile.png"
                  width={"100%"}
                />
              </Box>
              <Typography
                variant="body1"
                style={{
                  fontWeight: "600",
                  color: "#fff",
                  marginTop: "5px",
                  marginBottom: "-5px",
                }}
              >
                Hi There !
              </Typography>
              <Typography
                variant="overline"
                style={{
                  fontWeight: "500",
                  color: "#fff",
                }}
              >
                Welcome To City Chat
              </Typography>
            </Box>
          </Box>
          <Box class="scrollbar" id="style-3" height={255}>
            <Box class="force-overflow">
              <Box>
                {chatJson.map((data, index) => {
                  return (
                    <Box p={"20px"}>
                      <Box display={"flex"} alignItems={"center"} mt={1}>
                        <Box maxWidth={50} maxHeight={50} style={{}}>
                          <Avatar
                            alt="Remy Sharp"
                            src="/images/meteryard/Images/chat-user.webp"
                            sx={{ width: 30, height: 30 }}
                          />
                        </Box>
                        &nbsp; &nbsp;
                        <Box
                          style={{
                            padding: "3px 20px",
                            background: "#FFD99F",
                            borderRadius: "50px 50px 50px 0",
                            maxWidth: 175,
                          }}
                        >
                          <Typography
                            variant="overline"
                            style={{
                              fontWeight: "600",
                              marginTop: "5px",
                              marginBottom: "-5px",
                              color: "#000",
                            }}
                          >
                            {data?.text}
                          </Typography>
                        </Box>
                        &nbsp; &nbsp;
                        <Box>
                          <Typography
                            variant="overline"
                            style={{ color: "#000" }}
                          >
                            4:45 PM
                          </Typography>
                        </Box>
                      </Box>
                      <Box display={"flex"} justifyContent={"end"} mt={1}>
                        <Box display={"flex"} alignItems={"center"}>
                          <Box>
                            <Typography
                              variant="overline"
                              style={{ color: "#000" }}
                            >
                              4:45 PM
                            </Typography>
                          </Box>
                          &nbsp; &nbsp;
                          <Box
                            style={{
                              padding: "3px 20px",
                              background: "#F0F0F0",
                              borderRadius: "50px 50px 50px 0",
                              maxWidth: 175,
                            }}
                          >
                            <Typography
                              variant="overline"
                              style={{
                                fontWeight: "600",
                                marginTop: "5px",
                                marginBottom: "-5px",
                                color: "#000",
                              }}
                            >
                              {data?.text}
                            </Typography>
                          </Box>
                          &nbsp; &nbsp;
                          <Box maxWidth={50} maxHeight={50} style={{}}>
                            <Avatar
                              alt="Remy Sharp"
                              src="/images/meteryard/Images/chat-user.webp"
                              sx={{ width: 30, height: 30 }}
                            />
                          </Box>
                        </Box>
                      </Box>
                    </Box>
                  );
                })}
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
      <Box
        style={{
          position: "absolute",
          bottom: "0",
          right: "50px",
          zIndex: 1,
        }}
      >
        <Box maxWidth={100}>
          <img
            src="/images/meteryard/Images/chat-boat-icon.gif"
            style={{
              borderRadius: "50px",
            }}
          />
        </Box>
      </Box>
    </div>
  );
};

export default ChatBoat;
