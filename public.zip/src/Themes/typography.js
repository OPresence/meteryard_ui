export default {
  h1: {
    fontWeight: "600",
    color: "#000",
    lineHeight: "1.2",
    fontSize: "26px",
    fontFamily: "system-ui",
  },
  h2: {
    fontSize: "22px",
    lineHeight: "1.2",
    fontWeight: "400",
    color: "#000",
    fontFamily: "system-ui",
  },
  h3: {
    fontSize: "18px",
    lineHeight: "1.2",
    fontWeight: "400",
    color: "#000",
    fontFamily: "system-ui",
  },
  h4: {
    fontSize: "20px",
    fontWeight: "600",
    color: "#000",
    fontFamily: "system-ui",
  },
  h5: {
    fontSize: "22px",
    fontWeight: "500",
    color: "#000",
    fontFamily: "system-ui",
  },
  h6: {
    fontSize: "16px",
    fontWeight: "400",
    color: "#000",
    fontFamily: "system-ui",
  },
  overline: {
    fontSize: "18px",
    fontFamily: "system-ui",
    marginBottom: "15px",
    fontWeight: "bold",
    textTransform: "uppercase",
    textAlign: "justify",
    color: "#999",
  },

  button: {
    textTransform: "capitalize",
    borderRadius: 27,
    fontFamily: "system-ui",
  },

  body1: {
    fontSize: "14px",
    fontWeight: "400",
    color: "#000",
    textAlign: "justify",
    fontFamily: "system-ui",
  },
};
